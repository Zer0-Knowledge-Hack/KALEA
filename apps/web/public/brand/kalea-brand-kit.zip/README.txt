Kalea brand kit
===============

Kalea is Basque for "the street". The mark is a street between two buildings whose silhouette forms a crown.

Contents
  logo/svg, logo/png        Lockups, marks, app icon and favicon (PNG: transparent, 1024 px long side).
  elements/svg, elements/png  Street perspective, crown pattern tile and street plate.
  tokens.json               Colors, fonts and radii. Take values from here, not from screenshots.
  kalea-brand-guidelines-*.pdf  The full guide in English, Spanish and Brazilian Portuguese.

Quick rules
  - Use kalea-lockup on light backgrounds, kalea-lockup-on-dark on Ocean, Deep or dark photos.
  - Clear space: half the mark height on every side. Minimum size: mark 16 px tall, lockup 80 px wide.
  - Do not recolor, stretch, rotate or add effects to the logo, and do not redraw the mark.
  - Apricot (#EE9E4F) is never used for text on white.

Online guide: the /brand/ page on the Kalea website.
Source: https://github.com/Zer0-Knowledge-Hack/KALEA/tree/main/brand
Questions and co-branding: https://github.com/Zer0-Knowledge-Hack/KALEA/issues
